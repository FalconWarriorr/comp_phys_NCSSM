h5hep package
=============

Submodules
----------

h5hep\.read module
------------------

.. automodule:: h5hep.read
    :members:
    :undoc-members:
    :show-inheritance:

h5hep\.write module
-------------------

.. automodule:: h5hep.write
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: h5hep
    :members:
    :undoc-members:
    :show-inheritance:
