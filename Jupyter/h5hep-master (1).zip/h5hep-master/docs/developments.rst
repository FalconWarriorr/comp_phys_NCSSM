============
 Development
============

Because the basic data is imported into an environment, users have access to the 
full python ecosystem and are encouraged to expand upon these visualizations
and analysis functions. 

If you come up with something useful, you can contact the authors 
easiest by filing a bug request (either with a bug or feature) on 
`the Github site <https://github.com/mattbellis/h5hep>`_. You can either send
us snippets of code that we can include in the ``examples`` or ``scripts`` directories
or fork us and file a *pull request*.
