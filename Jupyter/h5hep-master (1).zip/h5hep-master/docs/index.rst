.. h5hep documentation master file, created by
   sphinx-quickstart on Sun Sep 17 01:54:46 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to h5hep's documentation!
=================================

This project gives you ROOT-file functionality but substituting
HDF5 instead. 

.. toctree::
   :maxdepth: 5
   :caption: Contents:

.. _h5hep: https://github.com/mattbellis/h5hep


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
